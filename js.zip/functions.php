<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently version.
 */
define( 'IDCONNECT_VERSION', '1.0.0' );
<?php

// redirect 404
add_action('template_redirect', 'redirect_404');